<?php

   // The first one I found on Google
  
  $url_of_img=$_GET['url'];

$width="1440";
$height="";

if(isset($_GET['width'])){


$width=$_GET['width'];

}


if(isset($_GET['height'])){




$height="--height ".$_GET['height'];

}


$myFile = pathinfo($url_of_img);


 $fl_name=explode(".",$myFile['basename'])[0];
$file_name="./img/".date("h:i:sa").$fl_name.".jpg";
$com="wkhtmltoimage --disable-smart-width --width ".$width." ".$height." ".$url_of_img." ".$file_name;

  exec("wkhtmltoimage --disable-smart-width  --width ".$width."  ".$height." ".$url_of_img." ".$file_name);



$im = file_get_contents($file_name);
header("Content-type: image/jpeg");
echo $im;



unlink($file_name);

   ?>
